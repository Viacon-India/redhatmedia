<?php
/*
 * Template Name: Brand Template
 */
get_header();
global $redhatm;
?>

<!-- <div class="banner">
    <div class="container">
        <div class="banner-content">
            <h1 class="page-title">My Companies</h1>
            <p class="page-intro">In the past couple of years, I have built commercial and financial entities that are aimed at solving Digital Marketing problems in a simple, effective and affordable fashion. I do not believe that expertise needs to be expensive in order to be successful. You simply find a lacunae and plug it with experience, knowledge and skills. </p>
        </div>
    </div>
</div> -->
<section class="brand-page">
    <div class="container">

        <?php /*$categories = get_categories( array(
		    'orderby' => 'name',
		    'parent'  => 0
		) );  */
		$categories = get_terms( 'niches', array(
		    'hide_empty' => true,
		    'orderby' => 'date',
		    'order' => 'DESC'
		) );
		?>

        <ul class="nav nav-tabs nav-justified md-tabs indigo" id="myTabJust" role="tablist">

        	<?php $cf = 1;
        	foreach ( $categories as $category ) { ?>
	          <li class="nav-item">
	            <a class="nav-link <?php if($cf == 1) { echo 'active'; } ?>" id="<?php echo $category->slug; ?>-tab-just" data-toggle="tab" href="#<?php echo $category->slug; ?>-just" role="tab" aria-controls="<?php echo $category->slug; ?>-just"
	              aria-selected="true"><?php echo $category->name; ?></a>
	          </li>
	        <?php 
	        $cf++;
	    	} ?>

        </ul>
        <div class="tab-content pt-5" id="myTabContentJust">        	

        	<?php $cs = 1;
        	foreach ( $categories as $category ) { ?>

	          <div class="tab-pane fade show <?php if($cs == 1) { echo 'active'; } ?>" id="<?php echo $category->slug; ?>-just" role="tabpanel" aria-labelledby="<?php echo $category->slug; ?>-tab-just">

	          	<div class="blog-sec">
    				<div class="card-bg">

			          	<ul class="cards">

				            <?php $lastposts = get_posts( array(
							    'posts_per_page' => 4,
							    'post_type' => 'brand',
							    'tax_query' => array(
								    array(
								      'taxonomy' => 'niches',
								      'field' => 'id',
								      'terms' => $category->term_id
								    )
								)
							) );

							if ( $lastposts ) {
							    foreach ( $lastposts as $post ) : setup_postdata( $post ); ?>

							        <li class="cards_item">
									    <div class="card">
									        <div class="card_image">
									        	<!-- <a href="<?php the_permalink(); ?>"> -->
									        		<?php the_post_thumbnail( 'full', array('class' => 'attachment-blog-thumbnail size-blog-thumbnail wp-post-image')); ?>
									        	<!-- </a> -->
									        </div>
									        <div class="card_content">
									            <h2 class="card_title">
									            	<!-- <a href="<?php //the_permalink(); ?>"> -->
									            		<?php the_title(); ?>
									            	<!-- </a> -->
									            </h2>
									            <div class="card_text">
									            	<?php echo substr($post->post_content,0,80); ?>
									            </div>
									            <!-- <a class="btn card_btn" href="<?php the_permalink(); ?>">Read More</a> -->
									        </div>
									    </div>
									</li>

							    <?php
							    endforeach; 
							    wp_reset_postdata();
							}
							?>
						</ul>

					</div>
    			</div>
	            	            

	          </div>

	        <?php 
	        $cs++;
	    	} ?>

	    	<a href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>" class="btn btn-primary">View All </a>	    	

        </div>

    </div>
</section>




<?php
get_footer();
